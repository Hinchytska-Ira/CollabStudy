// js/loadHeader.js
document.addEventListener("DOMContentLoaded", () => {
  fetch("/pages/header.html")
    .then(res => {
      if (!res.ok) throw new Error("Header not found");
      return res.text();
    })
    .then(data => {
      document.getElementById("header-placeholder").innerHTML = data;
    })
    .catch(err => {
      console.error("❌ Не вдалося завантажити header:", err.message);
    });
});
